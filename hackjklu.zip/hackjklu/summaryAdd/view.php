<?php
// Connect to database
$servername = "localhost";
$username = "varun";
$password = "varun";
$dbname = "summary";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Retrieve records
$sql = "SELECT * FROM mytable";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table>";
  echo "<tr><th>ID</th><th>Book Name</th><th>Chapter</th><th>Summary</th></tr>";
  while($row = $result->fetch_assoc()) {
    echo "<tr><td>" . $row["id"] . "</td><td>" . $row["bookname"] . "</td><td>" . $row["chaptername"] . "</td><td>" . $row["conent"] . "</td></tr>";
  }
  echo "</table>";
} else {
  echo "No records found";
}

// Close database connection
$conn->close();
?>