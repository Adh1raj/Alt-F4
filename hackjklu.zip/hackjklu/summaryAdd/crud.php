<?php
// Connect to database
$servername = "localhost";
$username = "varun";
$password = "varun";
$dbname = "summary";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Handle CRUD operations
if (isset($_POST['action'])) {
  // Insert record
  if ($_POST['action'] == 'insert') {
    $bookname = $_POST['bookname'];
    $chaptername = $_POST['chaptername'];
    $summary = $_POST['conent'];
    
    $sql = "INSERT INTO mytable (bookname, chaptername, conent) VALUES ('$bookname', '$chaptername', '$summary')";
    if ($conn->query($sql) === TRUE) {
      echo "Record inserted successfully";
    } else {
      echo "Error inserting record: " . $conn->error;
    }
  }

  // Update record
  if ($_POST['action'] == 'update') {
    $id = $_POST['id'];
    $bookname = $_POST['bookname'];
    $chaptername = $_POST['chaptername'];
    $summary = $_POST['conent'];
       $sql = "UPDATE mytable SET bookname='$bookname', chaptername='$chaptername', conent='$summary' WHERE id=$id";
if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}
}

// Delete record
if ($_POST['action'] == 'delete') {
$id = $_POST['id'];


$sql = "DELETE FROM mytable WHERE id=$id";
if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}
}
}

// Close database connection
$conn->close();
?>